# Divination.py
# Static board position evaluator — reads the tea leaves and returns a score.
# Higher score = better position for the current player (us).
# Called at every leaf node of the game tree search in SpellCasting.py.
# The score has no absolute meaning — only relative comparisons matter.

from game.enums import Cell, BOARD_SIZE

# The geometric centre of the board sits between cells 3 and 4 in each axis.
# We use 3.5 (not an integer) so distance-to-centre is always > 0.
_C = BOARD_SIZE / 2.0 - 0.5   # = 3.5 for an 8x8 board


# ─────────────────────────────────────────────────────────────────────────────
# Tiny helper functions pulled to module level so the main loop stays readable.
# ─────────────────────────────────────────────────────────────────────────────

def _md(a, b):
    # Manhattan distance between two (x,y) board locations.
    # Used everywhere — player-to-cell, player-to-player, Scabbers-to-centre.
    return abs(a[0]-b[0]) + abs(a[1]-b[1])

def _cd(p):
    # Manhattan distance from point p to the board centre (3.5, 3.5).
    # Central positions are more valuable early game — more directions to build.
    return abs(p[0]-_C) + abs(p[1]-_C)

def _sc(h, x, y):
    # Count straight-line (cardinal) primed neighbors of cell (x,y).
    # A cell with 2+ straight connections is a hub — it can be rolled in multiple directions.
    # A cell with 1 straight connection is a chain endpoint — building toward a roll.
    return sum(
        1 for dx,dy in ((0,1),(1,0),(0,-1),(-1,0))       # all four cardinal directions
        if 0<=x+dx<BOARD_SIZE and 0<=y+dy<BOARD_SIZE     # stay in bounds
        and h.get_cell((x+dx,y+dy))==Cell.PRIMED          # neighbor must be primed
    )

def _dc(h, x, y):
    # Count diagonal primed neighbors of cell (x,y).
    # Diagonals don't make a rollable chain but indicate dense primed territory.
    # Combined with 1 straight neighbor → still counts as a hub-like structure.
    return sum(
        1 for dx,dy in ((1,1),(1,-1),(-1,1),(-1,-1))     # all four diagonal directions
        if 0<=x+dx<BOARD_SIZE and 0<=y+dy<BOARD_SIZE     # stay in bounds
        and h.get_cell((x+dx,y+dy))==Cell.PRIMED          # neighbor must be primed
    )


def readTheLeaves(hogwarts, marauderMap, footprintHistory=None, darkArtsRate=0.5, _p=None):
    # _p is an unused legacy parameter — kept to avoid breaking any callers that pass it.

    # ── Extract board state ───────────────────────────────────────────────────
    pw, ow = hogwarts.player_worker, hogwarts.opponent_worker  # our wizard and the dark wizard
    diff   = pw.get_points() - ow.get_points()   # positive = we're winning on points
    glass  = max(1, pw.turns_left)               # turns remaining (floor at 1 to avoid div/0)
    us     = pw.get_location()                   # our current (x,y) position
    them   = ow.get_location()                   # opponent's current (x,y) position

    # ── Phase and lead metrics ────────────────────────────────────────────────
    sand = glass / 40.0          # 1.0 = full hourglass (start), 0.0 = last grain (end)
    adv  = max(-1.0, min(1.0, diff / 10.0))  # clamped lead ratio: +1 = dominant, -1 = losing badly
    gap  = _md(us, them)         # how far apart are the two wizards right now
    aDst = _cd(us)               # how far are WE from the centre of the board
    # momentum: 1.0 when far apart (safe to build), 0.0 when enemy is right next to us
    mom  = max(0.0, min(1.0, (gap - 3.0) / 5.0))

    # ── Dynamic spell weights — all shift based on phase, lead, opponent behavior ──
    # sGrav: how hard the heuristic pulls us toward Scabbers' most likely location.
    #        Falls when winning (don't gamble), rises when opponent hunts a lot.
    sGrav = 27.6 - adv*34.5 + darkArtsRate*23.0*sand

    # enc: bonus for cells that form one end of a chain (1 straight neighbor).
    #      More valuable when we have momentum (opponent is far away).
    enc   = 41.4 - adv*11.5 + mom*11.5

    # terr: how much we value controlling primed cells in our half of the board.
    #       Rises when winning (protect our work), falls when losing (need to gamble).
    terr  = 19.55 + adv*9.2 + (0.5 - darkArtsRate)*5.75

    # hub: reward for cells that are connected hubs (2+ straight or 1 straight + diagonal).
    #      These are the cells that can be carpet-rolled in multiple directions — very valuable.
    #      Rises early game and when there's space to manoeuvre.
    hub   = 80.5 * sand**1.5 + mom*45.0

    # dmk: penalty when opponent is close enough to roll our chain (Dark Mark threat).
    #      Rises as the game goes on — late-game threats are more decisive.
    dmk   = 23.0 + adv*34.5 + (1.0-sand)*46.0

    # hrx: reward for standing next to opponent's primed chains to destroy them (Horcrux hunting).
    #      Rises when losing (need to disrupt), falls when winning (protect lead instead).
    hrx   = 45.0 - adv*80.0 + 20.0/(gap+1.0)

    # ── Meta adjustments based on where Scabbers is lurking ──────────────────
    scLoc, _ = marauderMap.mostWanted()   # most suspicious cell for Scabbers
    if darkArtsRate > 0.6 and _cd(scLoc) < 2.0:
        # Opponent is hunting aggressively AND Scabbers is near centre — honeypot situation.
        # Drastically reduce our own Scabbers gravity (don't chase into a crowded area)
        # and boost chain building instead (safer use of our turns).
        sGrav *= 0.3    # almost ignore Scabbers' location when opponent is hunting the atrium
        enc   += 27.6   # compensate by valuing chain building more

    # ── Base score: point lead is the most important signal ──────────────────
    base = diff * 230.0   # 230 points of heuristic value per crown of actual lead
    if footprintHistory and us in footprintHistory:
        # Penalize revisiting a chamber we've been in recently.
        # This breaks oscillation where the bot bounces between two cells.
        base -= 184.0   # ~80% of one point of lead — meaningful deterrent

    # Late game lead protection: if we're winning and near centre, bonus for staying put.
    if sand < 0.3 and diff > 0:
        if aDst >= 3:
            base += 46.0    # central positioning when winning late is very hard to crack
        hrx -= 34.5         # stop trying to steal opponent's chains — protect the lead

    # ── Accio Mobility: reward being central and agile ───────────────────────
    # Being near the centre of the board gives access to more directions.
    # More valuable when the hourglass is full (more turns to exploit it).
    mob = (18.4 * sand) / (aDst + 1.0)

    # ── Accumulators for the full board sweep ────────────────────────────────
    T    = 0.0   # total threat penalty  (opponent threatening our chains)
    gT   = 0.0   # grounded territory    (primed/carpet cell control)
    cE   = 0.0   # chain enchantment     (cells with exactly 1 straight neighbor — building)
    cB   = 0.0   # centre bonus          (cells that are hubs — rollable in 2+ directions)
    cF   = 0.0   # carpet forecast       (open cells we could prime and roll later)
    ctrl = 0.0   # board control         (Voronoi-style territorial dominance)

    # ── Full board sweep: evaluate every non-blocked cell ────────────────────
    for y in range(BOARD_SIZE):
        for x in range(BOARD_SIZE):
            ft = hogwarts.get_cell((x, y))   # floor type at this cell
            if ft == Cell.BLOCKED: continue  # collapsed corridor — nothing to evaluate here

            md = _md(us,   (x,y))   # how many steps for US to reach this cell
            od = _md(them, (x,y))   # how many steps for OPPONENT to reach this cell
            tp = od - md             # tempo: positive = we reach it first, negative = they do

            # ── Open and carpet cells: Voronoi territory race ─────────────────
            if ft not in (Cell.BLOCKED, Cell.PRIMED):
                # Reward open cells we can reach before the opponent (we claim them by priming)
                if   tp > 0: ctrl+=(3.45*sand)/(md+1.0); cF+=(5.75*sand)/(md+1.0)  # we're closer
                elif tp < 0: ctrl-=(3.45*sand)/(od+1.0); cF-=(5.75*sand)/(od+1.0)  # they're closer
                continue   # carpet cells don't need the primed-cell analysis below

            # ── Primed cells: the scoring infrastructure ──────────────────────
            if ft == Cell.PRIMED:
                sc = _sc(hogwarts,x,y)   # how many straight primed neighbors this cell has
                dc = _dc(hogwarts,x,y)   # how many diagonal primed neighbors this cell has

                if tp >= 0:
                    # OUR primed cell (we're closer or tied) — value it
                    if 0.4<sand<0.75 and sc==0:
                        # Mid-game isolated prime: creates obstacles the opponent has to navigate around.
                        # Only valuable during the building phase (not too early, not too late).
                        base += 29.9*sand   # bonus scales with how much hourglass remains

                    gT += terr/(md+1)   # territory value inversely proportional to our distance

                    # Hub detection: is this cell part of a structure that can be rolled?
                    if   sc>=2 or (sc==1 and dc>=1): cB += hub   # full hub — rollable in 2+ directions
                    elif sc==1:                       cE += enc*sand  # chain tip — building toward a hub

                    # Threat: is the opponent close enough to roll OUR chain?
                    if md > 0:  # skip if we're standing on it (no threat from ourselves)
                        if   tp==0 and od<=2: T += dmk        # tied position, opponent right there — danger
                        elif tp==1 and od<=2: T += dmk*0.3    # we're one step closer but still risky

                else:
                    # OPPONENT'S primed cell (they're closer) — penalize us for losing territory
                    gT -= terr/(od+1)   # territory loss proportional to their proximity advantage

                    # Desperation roll: if we're right next to their chain in the final turns, go for it
                    if glass<=4 and md<=1:
                        base += 1150   # massive bonus — stealing their carpet at the last second is huge

                    # Horcrux destruction: penalize/reward being next to opponent's chains
                    if md <= 1:
                        if sc>=3 and diff>=0:
                            # Their chain is massive AND we're winning — too risky to stand here
                            base -= 34.5   # they'll roll right over us for a huge score
                        else:
                            base += hrx              # standing next to their chain — can disrupt it
                            if sc >= 2: base += hrx  # double reward if chain is long — bigger target
                    elif md==2 and tp>=-1:
                        base += hrx*0.6   # two steps away — partial credit for proximity

            # ── Carpeted cells: already converted, still count as territory ───
            elif ft == Cell.CARPET:
                if tp >= 0: gT += 8.05   # flat territory bonus — it's done but it's ours

    # ── Scabbers pull: tug the score toward high-suspicion chambers ──────────
    # For each cell where Scabbers might be hiding, add a score bonus proportional
    # to how suspicious that cell is and how close we are to it.
    # This naturally blends rat-hunting into territorial play — we drift toward Scabbers
    # without having to explicitly decide to search every turn.
    pull = sum(
        marauderMap.getSuspicion((x,y)) * sGrav   # suspicion × how much we care about Scabbers
        / (_md(us,(x,y)) + 1.2)                   # divided by distance (closer = higher pull)
        for y in range(BOARD_SIZE) for x in range(BOARD_SIZE)
        if marauderMap.getSuspicion((x,y)) > 0.05  # ignore cells with negligible suspicion (<5%)
    )

    # ── Final prophecy: sum all contributing factors ─────────────────────────
    # base:  raw point lead (dominant signal)
    # pull:  Scabbers gravity (pull toward rat location)
    # mob:   mobility / centrality bonus
    # cF:    carpet forecast (open cells we could prime)
    # ctrl:  board control (Voronoi tempo)
    # cB:    hub bonus (well-connected primed cells)
    # gT:    grounded territory (primed/carpet control)
    # cE:    chain enchantment (single-connection building cells)
    # -T:    threat penalty (opponent threatening our chains)
    return base + pull + mob + cF + ctrl + cB + gT + cE - T
