# agent.py
# Main wizard class — the game engine calls play() once per turn.
# Maintains the Marauder's Map across turns, tracks opponent behavior,
# manages the time budget, and runs iterative deepening search to pick a spell.
# Class name must stay PlayerAgent and methods must stay play() and commentate().

import math
from .MarauderMap import MarauderMap                                    # HMM for Scabbers tracking
from .SpellCasting import chooseSpell, OutOfHourglass, GrimoireOfCutoffs  # search + helpers
from game.move import Move                                              # move constructor


def _rate(log):
    # Compute the opponent's Revelio rate: fraction of recent turns they spent searching.
    # Returns 0.5 (neutral) if log is empty — we assume average behavior until we know better.
    return sum(log)/len(log) if log else 0.5

def _budget(t, g, boost):
    # Compute how many seconds we should spend on this turn's search.
    # t: time remaining, g: turns remaining, boost: multiplier when we have a time surplus.
    # Floor at 0.15s (enough for at least depth 1) and ceiling at 15s (don't over-think).
    return max(0.15, min((t-1.5)/g*boost, 15.0))


class PlayerAgent:
    def __init__(self, hogwarts, apparition_matrix=None, timeTurner=None):
        # apparition_matrix: rat transition probabilities from the game engine (64×64)
        self.mm    = MarauderMap(apparition_matrix)          # the Marauder's Map — tracks Scabbers
        self.isA   = hogwarts.player_worker.is_player_a      # True if we're player A (goes first)
        self.g     = GrimoireOfCutoffs()                     # stores beta-cutoff spells across turns
        self.steps = []    # last 4 positions — used to penalize revisiting the same chamber
        self.dlog  = []    # opponent's recent Revelio log — 1.0 if they searched, 0.0 if not
        self._last = None  # last board state — saved for commentate() when no board is passed

    def commentate(self, hogwarts=None):
        # Called by the game engine at game end to get our end-of-game report.
        # The engine may or may not pass a board — we handle both cases gracefully.
        # When a board is available we do a full sweep of the position to build a
        # rich narrative: scores, board structure, Scabbers intelligence, time usage,
        # opponent tendencies, and a plain-English strategic verdict.
        from game.enums import Cell, BOARD_SIZE   # imported here to avoid circular imports at top

        h = hogwarts or self._last   # prefer the freshly passed board, fall back to saved state

        # ── Scabbers intelligence (always available, even without a board) ────
        scLoc, scProb    = self.mm.mostWanted()    # cell with highest suspicion right now
        scDist           = abs(scLoc[0]-3.5) + abs(scLoc[1]-3.5)  # Scabbers' distance from centre
        scEntropy        = float(-sum(                             # Shannon entropy of the belief map
            p * __import__('math').log2(p)
            for p in (self.mm.suspicion[self.mm.suspicion > 0])
        ))
        # High entropy = Scabbers could be almost anywhere (belief is spread out / uncertain)
        # Low entropy  = we have a strong read on where Scabbers is hiding

        # ── Opponent Revelio history ──────────────────────────────────────────
        dr           = _rate(self.dlog)                     # fraction of turns opponent searched
        totalRevelio = sum(self.dlog)                       # total number of times they searched
        # Classify the opponent's hunting style based on their search rate
        oppStyle = (
            "Rat Obsessed"   if dr > 0.70 else   # hunts more than 70% of turns — ignoring board
            "Active Hunter"  if dr > 0.45 else   # hunts regularly — balanced threat
            "Occasional"     if dr > 0.20 else   # hunts sometimes — mostly plays board
            "Pure Architect"                      # almost never searches — full territorial player
        )

        # ── Default values used when no board is available ────────────────────
        pts = opp = diff = turns = tLeft = 0
        ourLoc = theirLoc = (0, 0)
        ourPrimed = theirPrimed = sharedCarpet = 0
        ourDist = theirDist = ourMob = theirMob = 0
        longestOurChain = longestTheirChain = 0
        st = "STARTING"; ph = "EARLY"

        if h:
            # ── Basic score and phase metrics ─────────────────────────────────
            pts   = h.player_worker.get_points()      # our total score
            opp   = h.opponent_worker.get_points()    # opponent's total score
            diff  = pts - opp                         # our lead — positive means we're winning
            turns = h.player_worker.turns_left        # turns we have remaining
            tLeft = h.player_worker.time_left         # seconds remaining on our clock

            # Standing label — used in the headline of the report
            st = "WINNING" if diff > 0 else "LOSING" if diff < 0 else "TIED"
            # Game phase label — affects which strategic concerns matter most
            ph = "EARLY" if turns > 25 else "MID" if turns > 10 else "LATE"

            ourLoc   = h.player_worker.get_location()    # where our wizard is standing right now
            theirLoc = h.opponent_worker.get_location()  # where the opponent is standing right now

            # ── Full board sweep: count primed cells, carpet, and chain lengths ──
            # We iterate every cell to understand the structural state of the board.
            # This tells us who has more infrastructure and how close we are to cashing.
            ourPrimed    = 0   # primed cells closer to us than to opponent (our territory)
            theirPrimed  = 0   # primed cells closer to opponent (their territory)
            sharedCarpet = 0   # total carpeted cells on the board (already converted)
            curOurRun    = 0   # current consecutive primed run in our direction
            curTheirRun  = 0   # current consecutive primed run in their direction
            longestOurChain   = 0   # longest contiguous chain we could potentially roll
            longestTheirChain = 0   # longest contiguous chain opponent could potentially roll

            for y in range(BOARD_SIZE):
                for x in range(BOARD_SIZE):
                    cell = h.get_cell((x, y))
                    if cell == Cell.BLOCKED:
                        # Reset run counters when we hit a wall — can't roll through blocked cells
                        curOurRun = curTheirRun = 0
                        continue

                    if cell == Cell.CARPET:
                        sharedCarpet += 1   # already converted — counts as territory for whoever rolled it

                    if cell == Cell.PRIMED:
                        # Attribute this primed cell to whichever wizard is closer
                        ourDist   = abs(ourLoc[0]-x)   + abs(ourLoc[1]-y)    # our manhattan distance
                        theirDist = abs(theirLoc[0]-x) + abs(theirLoc[1]-y)  # their manhattan distance

                        if ourDist <= theirDist:
                            ourPrimed += 1       # we're closer — call it ours
                            curOurRun += 1       # extend our current run
                            longestOurChain = max(longestOurChain, curOurRun)  # track longest
                            curTheirRun = 0      # break their run counter
                        else:
                            theirPrimed += 1     # they're closer — call it theirs
                            curTheirRun += 1     # extend their current run
                            longestTheirChain = max(longestTheirChain, curTheirRun)
                            curOurRun = 0        # break our run counter

            # ── Mobility: how many adjacent cells each wizard can move to ─────
            # Low mobility = risk of getting trapped or having lines cut off
            ourMob = sum(
                1 for dx,dy in ((0,1),(1,0),(0,-1),(-1,0))
                if 0<=ourLoc[0]+dx<BOARD_SIZE and 0<=ourLoc[1]+dy<BOARD_SIZE
                and h.get_cell((ourLoc[0]+dx, ourLoc[1]+dy)) not in (Cell.BLOCKED, Cell.PRIMED)
            )
            theirMob = sum(
                1 for dx,dy in ((0,1),(1,0),(0,-1),(-1,0))
                if 0<=theirLoc[0]+dx<BOARD_SIZE and 0<=theirLoc[1]+dy<BOARD_SIZE
                and h.get_cell((theirLoc[0]+dx, theirLoc[1]+dy)) not in (Cell.BLOCKED, Cell.PRIMED)
            )

        # ── Wizard proximity: how close are we to the opponent ────────────────
        proximity = abs(ourLoc[0]-theirLoc[0]) + abs(ourLoc[1]-theirLoc[1])
        # Close = high disruption potential (and high risk of being disrupted)
        # Far = both playing independently — territorial game dominates

        # ── Determine the strategic meta label ───────────────────────────────
        # This summarizes the overall strategic posture we ended the game in
        meta = (
            "Balance"       if dr > 0.6 and scDist < 2.0 else  # opponent hunting centre — honeypot risk
            "Steal"         if turns < 12 and diff > 0   else  # late game lead — hunt their chains
            "Fortify"       if diff > 5 and turns < 15   else  # big lead, protect it
            "Desperate"     if diff < -8 and turns < 10  else  # losing badly late — gamble
            "Standard"                                          # default mid-game building
        )

        # ── Carpet point projections ──────────────────────────────────────────
        # Estimate what our longest chain would score if rolled right now
        from game.enums import CARPET_POINTS_TABLE
        projectedOurScore   = CARPET_POINTS_TABLE.get(longestOurChain,   0) if longestOurChain   >= 1 else 0
        projectedTheirScore = CARPET_POINTS_TABLE.get(longestTheirChain, 0) if longestTheirChain >= 1 else 0

        # ── Scabbers confidence classification ───────────────────────────────
        # Plain English description of how confident we are about Scabbers' location
        scConfidence = (
            "LOCKED IN"    if scProb > 0.80 else   # nearly certain — should search immediately
            "STRONG READ"  if scProb > 0.55 else   # high confidence — worth searching
            "DECENT LEAD"  if scProb > 0.35 else   # moderate confidence — board situation dependent
            "SCATTERED"    if scProb > 0.15 else   # belief is spread out — risky to search
            "NO IDEA"                               # totally lost — don't waste a turn searching
        )

        # ── Time pressure assessment ──────────────────────────────────────────
        timePerTurn   = round(tLeft / max(1, turns), 2)   # seconds available per remaining turn
        timePressure  = (
            "CRITICAL"   if timePerTurn < 1.0 else   # under 1s per turn — must move fast
            "TIGHT"      if timePerTurn < 3.0 else   # under 3s — limited search depth
            "COMFORTABLE"                              # plenty of time — can search deep
        )

        # ── Build the full report ─────────────────────────────────────────────
        lines = [
            # Headline: standing, phase, and score
            f"╔══════════════════════════════════════════════════════╗",
            f"  GAME REPORT — {st} | {ph} GAME",
            f"  Score: {pts} (us) vs {opp} (them)  |  Lead: {diff:+d} pts",
            f"  Turns remaining: {turns}  |  Time left: {tLeft:.1f}s ({timePerTurn:.1f}s/turn) [{timePressure}]",
            f"",
            # Board structure
            f"  BOARD STRUCTURE",
            f"  Our primed cells:     {ourPrimed:2d}  |  Longest chain: {longestOurChain} cells",
            f"  Their primed cells:   {theirPrimed:2d}  |  Longest chain: {longestTheirChain} cells",
            f"  Carpeted cells total: {sharedCarpet:2d}",
            f"  Projected roll value: us +{projectedOurScore}  |  them +{projectedTheirScore}",
            f"",
            # Positioning
            f"  POSITIONING",
            f"  Our location:   {ourLoc}  |  Mobility: {ourMob} open neighbors",
            f"  Their location: {theirLoc}  |  Mobility: {theirMob} open neighbors",
            f"  Wizard proximity (manhattan): {proximity} steps apart",
            f"",
            # Scabbers intelligence
            f"  SCABBERS INTELLIGENCE",
            f"  Most likely location: {scLoc}  ({scProb:.1%} confidence) — {scConfidence}",
            f"  Belief entropy: {scEntropy:.2f} bits  (lower = more certain)",
            f"  Scabbers distance from centre: {scDist:.1f} cells",
            f"",
            # Opponent analysis
            f"  OPPONENT TENDENCIES",
            f"  Revelio rate: {dr:.0%} over last {len(self.dlog)} turns  ({int(totalRevelio)} total searches)",
            f"  Opponent style: {oppStyle}",
            f"",
            # Strategic verdict
            f"  STRATEGIC VERDICT",
            f"  Mode: {meta}",
            f"╚══════════════════════════════════════════════════════╝",
        ]

        return "\n".join(lines)

    def play(self, hogwarts, clues, timeTurner):
        # Called once per turn. Returns a Move object.
        self._last = hogwarts   # save for commentate() in case engine calls it without a board

        # ── Step 1: update the map with last turn's Revelio result ───────────
        # If we searched last turn, update the map with what we found (or didn't find).
        ps = hogwarts.player_search   # (location, found) tuple — (None, False) if we didn't search
        if ps and ps[0] is not None:
            # We searched a cell last turn
            self.mm.mischiefsManaged() if ps[1] else self.mm.notHere(ps[0])
            # mischiefsManaged() = Scabbers caught, reset map
            # notHere() = Scabbers wasn't there, zero that cell out

        # ── Step 2: advance the map for opponent's elapsed turn ──────────────
        # Skip this on player A's very first turn — the rat hasn't moved yet relative to our prior.
        skip = self.isA and hogwarts.player_worker.turns_left == 40
        if not skip:
            self.mm.scamper()   # Scabbers moved one step during the opponent's turn

            # Process opponent's Revelio result if they searched on their turn
            os = getattr(hogwarts, 'opponent_search', None)  # (location, found) or (None, False)
            if os and os[0] is not None:
                self.dlog.append(1.0)   # opponent cast Revelio — record it
                self.mm.mischiefsManaged() if os[1] else self.mm.notHere(os[0])
            elif os is not None:
                self.dlog.append(0.0)   # opponent did NOT cast Revelio — record that too

        # Keep only the last 8 turns of opponent behavior — older data is stale
        if len(self.dlog) > 8: self.dlog.pop(0)

        # ── Step 3: advance the map for our own turn ─────────────────────────
        # Scabbers moves one more step before our sensor fires
        self.mm.scamper()
        # Update the map with this turn's sensor clues (noise + distance)
        self.mm.hearsay(hogwarts, clues)

        # ── Step 4: compute context variables ────────────────────────────────
        glass = max(1, hogwarts.player_worker.turns_left)   # turns left (floor at 1)
        loc   = hogwarts.player_worker.get_location()       # our current chamber

        # Track footprints — penalizes revisiting the same chamber in Divination.py
        self.steps.append(loc)
        if len(self.steps) > 4: self.steps.pop(0)   # keep only last 4 positions

        dr     = _rate(self.dlog)   # fraction of recent opponent turns spent casting Revelio
        tLeft  = timeTurner()       # seconds remaining in our total time bank

        # Boost multiplier: if we have plenty of time, spend more per turn
        boost  = 1.5 if tLeft > 40 else 1.0
        budget = _budget(tLeft, glass, boost)   # seconds to spend on this turn's search
        safe   = max(0.05, tLeft - budget)       # minimum clock value before we abort search

        t0 = timeTurner()   # snapshot of time at the start of this turn (for usage tracking)

        # ── Step 5: iterative deepening search ───────────────────────────────
        # Start with the first valid move as a safe fallback in case we run out of time
        fb   = hogwarts.get_valid_moves(exclude_search=True)   # all legal board moves
        best = fb[0] if fb else Move.search((3,3))             # fallback if nothing available
        prev = 0      # score from the last completed depth (used to center aspiration window)
        hist = self.steps[:-1]   # all footprints except the current one (penalize revisiting these)

        for d in range(1, 51):   # search depths 1 through 50 — time check stops this naturally
            try:
                # Aspiration window: start narrow around prev score, widen if we fall outside
                w = 400 + d*50          # window width grows with depth (deeper = less certain)
                lo, hi = prev-w, prev+w  # [lo, hi] bracket around expected score

                # Time check: abort if we've used too much of this turn's budget
                used = t0 - timeTurner()   # seconds used so far this turn
                if tLeft > 60:
                    # Large time surplus: push depth until we're actually near the safety net
                    if timeTurner() < safe+0.05: break   # within 50ms of limit — stop
                elif used > budget*0.8:
                    # Normal time: stop after using 80% of the budget (leave margin for the next call)
                    break

                # Run the search at this depth with the aspiration window
                s, sc = chooseSpell(hogwarts, self.mm, d, timeTurner, safe, self.g, lo, hi, hist, dr)

                if sc<=lo or sc>=hi:
                    # Score fell outside our aspiration window — re-search with full bounds
                    # This is uncommon but important for correctness
                    s, sc = chooseSpell(hogwarts, self.mm, d, timeTurner, safe, self.g, -math.inf, math.inf, hist, dr)

                if s:
                    prev=sc    # update expected score for next iteration's aspiration window
                    best=s     # promote this depth's result — it's the new best complete answer

                # If this depth used more than 60% of budget, the next depth likely won't finish
                if t0-timeTurner() > budget*0.6: break

            except OutOfHourglass:
                # Time ran out mid-search — keep whatever best move we have from the last complete depth
                break

        return best   # return the best spell from the deepest fully-completed search
