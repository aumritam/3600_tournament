# SpellCasting.py
# Game tree search — Principal Variation Search (PVS) with alpha-beta pruning.
# Explores the space of possible future board states to find the best spell to cast.
# Also decides whether to cast Revelio (search for Scabbers) or make a board move.

import math
from .Divination import readTheLeaves   # static board evaluator — called at every leaf node
from game.enums import MoveType, Cell   # spell types and cell types
from game.move import Move              # move constructor used to return search decisions

_INF = math.inf   # shorthand for infinity — used as initial alpha/beta bounds


# ─────────────────────────────────────────────────────────────────────────────
# Exception raised when the Time-Turner runs out mid-search.
# Caught in agent.py to gracefully return the best move found so far.
# ─────────────────────────────────────────────────────────────────────────────
class OutOfHourglass(Exception): pass


# ─────────────────────────────────────────────────────────────────────────────
# Stores moves that caused beta cutoffs (proved too good for the opponent to allow).
# These "Unforgiveable" moves are tried first at the same depth in future iterations
# because they're likely to cause cutoffs again — major pruning speedup.
# ─────────────────────────────────────────────────────────────────────────────
class GrimoireOfCutoffs:
    def __init__(self): self.unforgiveables = {}  # depth (int) → Move that cut off at that depth


# ─────────────────────────────────────────────────────────────────────────────
# Small helper predicates — pulled to module level to keep the search clean.
# ─────────────────────────────────────────────────────────────────────────────

def _isLoud(s):
    # A "loud" spell is one that has an immediate tactical impact — prime or carpet.
    # Used to filter the quiescence search to only tactically relevant moves.
    return s.move_type in (MoveType.PRIME, MoveType.CARPET)

def _isCarpet(s):
    # Is this spell a carpet roll? Used for filtering short carpets in chooseSpell.
    return s.move_type == MoveType.CARPET


def _hotSquare(h):
    # Is our wizard standing next to a primed cell right now?
    # A hot square means a chain roll could happen on the very next spell —
    # the position is tactically volatile, so we extend into quiescence search.
    loc = h.player_worker.get_location()   # our current chamber
    return any(
        h.get_cell((loc[0]+dx, loc[1]+dy)) == Cell.PRIMED   # neighbor is primed
        for dx,dy in ((0,1),(1,0),(0,-1),(-1,0))             # check all four cardinal neighbors
        if 0<=loc[0]+dx<8 and 0<=loc[1]+dy<8                 # stay in bounds
    )


def _rank(s, d, g):
    # Assign a priority score to a spell for move ordering.
    # Better ordering → more alpha-beta cutoffs → faster search.
    # Priority order: unforgiveable cutoff > long carpet > short carpet > search > prime > plain
    if d in g.unforgiveables and str(s)==str(g.unforgiveables[d]):
        return 100   # this move caused a cutoff before at this depth — always try it first
    if _isCarpet(s):
        return 4 + s.roll_length   # longer carpet = more points = higher priority
    if s.move_type==MoveType.SEARCH:
        return 3   # searching for Scabbers — decent priority
    if s.move_type==MoveType.PRIME:
        return 2   # laying enchanted floor — building infrastructure
    return 1       # plain movement — lowest priority, tried last


def _eval(h, mm, pos, dr):
    # Thin wrapper around readTheLeaves — called at every leaf node of the search.
    # pos: footprint history (recent positions) — only passed for our turns, not opponent's
    # dr:  opponent's dark arts (Revelio) rate — affects how much we care about Scabbers
    return readTheLeaves(h, mm, pos, dr)


# ─────────────────────────────────────────────────────────────────────────────
# Quiescence Search — extends past depth 0 on loud moves only.
# Prevents the "horizon effect": a chain rollup just outside our search window
# looks neutral from inside but is actually a massive point swing.
# Uses stand-pat pruning: if static eval already beats beta (our turn), prune now.
# ─────────────────────────────────────────────────────────────────────────────
def _qsearch(h, mm, rem, a, b, ours, tt, cut, g, pos, dr):
    # Get the static evaluation of this position without looking any deeper
    val = _eval(h, mm, pos if ours else None, dr)

    # Base cases: no remaining depth OR game is over — just return the static eval
    if rem==0 or h.is_game_over(): return val

    # Stand-pat pruning: if this position is already great, opponent won't let us get here
    if ours:
        if val>=b: return b    # position already beats beta — prune immediately
        if val>a:  a=val       # update alpha if static eval is our new floor
    else:
        if val<=a: return a    # position already below alpha — prune immediately
        if val<b:  b=val       # update beta if static eval is opponent's new ceiling

    # Only look at loud tactical spells — prime and carpet moves
    # Plain movement doesn't change the tactical situation, so skip it here
    loud = [s for s in h.get_valid_moves(enemy=not ours, exclude_search=True) if _isLoud(s)]
    if not loud: return val   # no loud moves available — static eval is our answer

    best = val   # stand-pat value is our baseline
    if ours:
        # Maximizing: look for any loud move that improves our position
        for s in loud:
            nx = h.forecast_move(s)          # apply the spell and get the new board state
            if not nx: continue              # skip if move was somehow invalid
            v = _qsearch(nx,mm,rem-1,a,b,False,tt,cut,g,pos,dr)  # recurse for opponent
            if v>best: best=v                # keep track of the best we found
            if best>=b: break               # beta cutoff — opponent won't allow this
            if best>a:  a=best              # raise alpha floor
    else:
        # Minimizing: opponent looks for loud moves that hurt us
        for s in loud:
            h.reverse_perspective()          # flip board so opponent's moves look like ours
            nx=h.forecast_move(s)            # forecast from opponent's perspective
            h.reverse_perspective()          # flip back immediately
            if not nx: continue
            nx.reverse_perspective()         # the resulting board needs to be flipped back too
            v = _qsearch(nx,mm,rem-1,a,b,True,tt,cut,g,pos,dr)   # recurse for our turn
            if v<best: best=v                # opponent wants to minimize
            if best<=a: break               # alpha cutoff — we wouldn't allow this
            if best<b:  b=best              # lower beta ceiling
    return best


# ─────────────────────────────────────────────────────────────────────────────
# Principal Variation Search (PVS / Negascout) — the core recursive search.
# Explores the game tree up to depth d, using alpha-beta pruning to skip branches
# that can't possibly affect the outcome. Also applies:
#   • Null-window probes on non-PV moves (cheap check before full search)
#   • Late Move Reduction (LMR) on plain moves ranked 4th+ at depth ≥ 3
#   • Quiescence search when the position is tactically hot
#   • GrimoireOfCutoffs move ordering for repeated searches at the same depth
# ─────────────────────────────────────────────────────────────────────────────
def _pvs(h, mm, d, a, b, ours, tt, cut, g, pos, dr):
    # Check the clock first — if we're out of time, abort immediately
    if tt() < cut: raise OutOfHourglass()

    # ── Base cases ────────────────────────────────────────────────────────────
    if d<=0 or h.is_game_over():
        if d==0 and _hotSquare(h):
            # Position is tactically hot — extend into quiescence rather than evaluate blindly
            return _qsearch(h,mm,2,a,b,ours,tt,cut,g,pos,dr)
        # Leaf node — return the static evaluation of this position
        return _eval(h, mm, pos if ours else None, dr)

    # Generate all legal board moves (no searching — that's handled separately in chooseSpell)
    moves = h.get_valid_moves(enemy=not ours, exclude_search=True)
    if not moves:
        return _eval(h, mm, pos if ours else None, dr)  # no moves — evaluate as-is

    # Sort moves by priority: unforgiveable → carpet → search → prime → plain
    moves.sort(key=lambda s:_rank(s,d,g), reverse=True)

    if ours:
        # ── Maximizing: our turn, try to get the highest possible score ───────
        best = -_INF   # start with the worst possible score
        for i,s in enumerate(moves):
            nx = h.forecast_move(s)     # apply the spell — returns new board state
            if not nx: continue          # skip invalid moves

            if i==0:
                # First move (PV candidate from ordering) — search with full window
                # This is the most likely best move, so we invest the full search here
                v = _pvs(nx,mm,d-1,a,b,False,tt,cut,g,pos,dr)
            else:
                # LMR: plain moves ranked 4th+ at depth ≥ 3 get a reduced search first.
                # If the reduced search surprises us (score > alpha), re-search at full depth.
                # Skip LMR if move is tactically important (prime/carpet) or position is hot.
                lmr = d>=3 and i>=3 and not _isLoud(s) and not _hotSquare(h)

                # Null-window probe at reduced or full depth
                v = _pvs(nx,mm,d-(2 if lmr else 1),a,a+0.1,False,tt,cut,g,pos,dr)
                if v>a and (lmr or a<v<b):
                    # Null window failed high (score beat alpha) — re-search at full depth
                    # For LMR: use alpha as lower bound (we only know it beat alpha)
                    # For normal: use v as lower bound (tighter window)
                    v = _pvs(nx,mm,d-1,a if lmr else v,b,False,tt,cut,g,pos,dr)

            if v>best: best=v           # update best score found so far
            if best>a: a=best           # raise alpha — we have a better guaranteed floor
            if a>=b:                    # beta cutoff — opponent won't allow this branch
                g.unforgiveables[d]=s   # remember this move caused a cutoff at this depth
                break                   # prune all remaining siblings
        return best

    else:
        # ── Minimizing: opponent's turn, they try to minimize our score ───────
        best = _INF    # start with the best possible score (from our perspective)
        for i,s in enumerate(moves):
            # Opponent moves from their own perspective — flip board, forecast, flip back
            h.reverse_perspective()         # make opponent's moves look like "our" moves
            nx=h.forecast_move(s)           # forecast from opponent's POV
            h.reverse_perspective()         # immediately restore original perspective
            if not nx: continue
            nx.reverse_perspective()        # the child board also needs to be flipped back

            if i==0:
                # PV candidate — full window search
                v = _pvs(nx,mm,d-1,a,b,True,tt,cut,g,pos,dr)
            else:
                lmr = d>=3 and i>=3 and not _isLoud(s) and not _hotSquare(h)
                # Probe from beta side (opponent wants to beat beta to cause a cutoff for us)
                v = _pvs(nx,mm,d-(2 if lmr else 1),b-0.1,b,True,tt,cut,g,pos,dr)
                if v<b and (lmr or a<v<b):
                    # Probe failed low (score beat beta from opponent's side) — re-search
                    v = _pvs(nx,mm,d-1,a,b if lmr else v,True,tt,cut,g,pos,dr)

            if v<best: best=v           # opponent keeps the minimum
            if best<b: b=best           # lower beta — opponent has a better guaranteed ceiling
            if a>=b:                    # alpha cutoff — we wouldn't allow this branch
                g.unforgiveables[d]=s
                break
        return best


# ─────────────────────────────────────────────────────────────────────────────
# Root search — called once per turn from agent.py.
# First decides whether to cast Revelio (search for Scabbers),
# then runs the full PVS tree search over all board moves.
# Returns (best_spell, score) from the deepest completed iteration.
# ─────────────────────────────────────────────────────────────────────────────
def chooseSpell(h, mm, depth, tt, cut, g, lo, hi, pos, dr):
    glass = max(1, h.player_worker.turns_left)                          # turns remaining (floor 1)
    lead  = h.player_worker.get_points() - h.opponent_worker.get_points()  # our current point lead

    # Get the most suspicious location and its probability from the Marauder's Map
    loc, prob = mm.mostWanted()
    loc = (int(loc[0]), int(loc[1]))   # ensure integer coordinates for Move.search()

    # Expected value of casting Revelio: +4 if Scabbers is there, -2 if not
    ev   = prob*4.0 - (1.0-prob)*2.0

    # Opportunity cost of searching: minimum 1.0, rises when we're already winning.
    # Capped at 3.0 (raised from 2.5) — the 90% bot builds faster so the cost of
    # a wasted search turn is higher. We need higher confidence before committing.
    cost = min(1.0 + max(0,lead)/glass, 3.0)

    # Suspicion threshold: minimum probability required before we'll search.
    # Raised base from 0.45 to 0.50 — the 90% bot's tighter belief model means
    # Scabbers is genuinely harder to locate. Searching at 35-40% was wasting too
    # many turns on low-confidence guesses against a faster-building opponent.
    # Rises when winning (don't gamble a lead), falls when opponent hunts a lot (mirror them).
    dom  = max(-1.0, min(1.0, lead/10.0))   # clamped lead ratio
    thr  = 0.50 + dom*0.15 - (dr-0.5)*0.15  # base 50%, adjusted for lead and opponent behavior

    # FORCE SEARCH: late game + high confidence = search regardless of board moves
    # A catch is worth 4 points and the positional value of any move drops near the end
    if glass<=12 and prob>=0.60:
        return Move.search(loc), 0   # return score 0 since we don't run tree search here

    # STANDARD REVELIO GATE: expected value must beat opportunity cost AND prob must beat threshold
    if ev>(cost+0.1) and prob>thr:
        return Move.search(loc), 0   # worth it — search for Scabbers

    # ── Board move selection ──────────────────────────────────────────────────
    spells = h.get_valid_moves(enemy=False, exclude_search=True)  # all legal board spells
    if not spells:
        return Move.search((3,3)), -10**16   # no board moves available — punt with a search

    # Filter out length-1 carpet rolls — they score -1 point and are almost never worth it.
    # Exception: very end of game with a big lead, take whatever carpet is left.
    minR = 1 if (glass<=3 and lead>=5) else 2   # minimum carpet roll length to consider
    pool = [s for s in spells if not (_isCarpet(s) and s.roll_length<minR)] or spells
    # fallback to unfiltered if filter removed everything (e.g. only length-1 carpets available)

    # Sort by priority — best moves first for maximum alpha-beta efficiency
    pool.sort(key=lambda s:_rank(s,depth,g), reverse=True)

    best = None       # best move found so far
    bsc  = -_INF      # best score found so far

    for i,s in enumerate(pool):
        if tt()<cut: raise OutOfHourglass()   # check time before evaluating each move

        nx = h.forecast_move(s)   # apply the spell and get the resulting board
        if not nx: continue        # skip if move was invalid (shouldn't happen but be safe)

        if i==0:
            # Principal variation spell — search with full aspiration window
            sc = _pvs(nx,mm,depth-1,lo,hi,False,tt,cut,g,pos,dr)
        else:
            # Null-window probe first (much cheaper than full search)
            sc = _pvs(nx,mm,depth-1,lo,lo+0.1,False,tt,cut,g,pos,dr)
            if lo<sc<hi:
                # Null window failed high — this move might be the PV, re-search with full bounds
                sc = _pvs(nx,mm,depth-1,sc,hi,False,tt,cut,g,pos,dr)

        if sc>bsc:
            bsc=sc   # new best score
            best=s   # new best spell

        lo = max(lo, bsc)   # raise lower bound (aspiration window tightening)

    return best or pool[0], bsc   # return best found, fallback to first in pool if all failed
