# MarauderMap.py
# Hidden Markov Model for tracking Scabbers across the board.
# Think of this as our enchanted parchment — it always knows where the rat is lurking.
# Updated every turn with sensor clues (noise + distance) from the game engine.

import numpy as np                    # all belief math is vectorized with numpy
from game.enums import Cell, Noise, BOARD_SIZE

# total number of cells on the board — 8x8 = 64
_SZ = BOARD_SIZE * BOARD_SIZE

# ─────────────────────────────────────────────────────────────────────────────
# Noise likelihood table: P(noise | floor_type)
# How likely is each sound given what kind of floor Scabbers is under?
# Scabbers squeaks on open space, scratches on primed floors, squeals on carpet.
# ─────────────────────────────────────────────────────────────────────────────
_RUSTLE = {
    Cell.BLOCKED: {Noise.SQUEAK: 0.50, Noise.SCRATCH: 0.30, Noise.SQUEAL: 0.20},  # muffled behind a wall
    Cell.SPACE:   {Noise.SQUEAK: 0.70, Noise.SCRATCH: 0.15, Noise.SQUEAL: 0.15},  # open floor, mostly squeaks
    Cell.PRIMED:  {Noise.SQUEAK: 0.10, Noise.SCRATCH: 0.80, Noise.SQUEAL: 0.10},  # enchanted floor, lots of scratching
    Cell.CARPET:  {Noise.SQUEAK: 0.10, Noise.SCRATCH: 0.10, Noise.SQUEAL: 0.80},  # carpet muffles everything but squeals
}

# ─────────────────────────────────────────────────────────────────────────────
# Distance error table: P(reported_dist - actual_dist)
# The enchanted sensor isn't perfect — it can report one too few or two too many.
# Most of the time (70%) it's correct, but 30% of readings have noise.
# ─────────────────────────────────────────────────────────────────────────────
_STEPS = {
    -1: 0.12,   # sensor underestimates by 1 — Scabbers closer than reported
     0: 0.70,   # sensor is accurate — most common case
     1: 0.12,   # sensor overestimates by 1
     2: 0.06,   # sensor overestimates by 2 — rare but possible
}

# ─────────────────────────────────────────────────────────────────────────────
# Utility: convert (x, y) board coordinate to flat array index and back
# We store the belief as a flat 1D array of length 64 (one entry per cell).
# Index formula: i = y * BOARD_SIZE + x
# ─────────────────────────────────────────────────────────────────────────────
def _idx(loc): return loc[1] * BOARD_SIZE + loc[0]   # (x,y) → flat index
def _loc(i):   return (int(i % BOARD_SIZE), int(i // BOARD_SIZE))  # flat index → (x,y)


class MarauderMap:
    # Tracks a probability distribution (self.suspicion) over all 64 cells.
    # Each entry is P(Scabbers is in that cell | everything we've observed so far).
    # High suspicion = Scabbers is probably there. Low suspicion = probably not.

    def __init__(self, apparition_matrix=None):
        # apparition_matrix[i][j] = P(Scabbers moves from cell i to cell j in one step)
        # If none is given, assume Scabbers moves uniformly at random (equal probability everywhere)
        self.T = (
            np.array(apparition_matrix, dtype=np.float64)  # use provided transition matrix
            if apparition_matrix is not None
            else np.ones((_SZ, _SZ)) / _SZ                 # uniform fallback
        )

        # Precompute T^1000 — what the belief looks like after 1000 random steps from (0,0)
        # This is the stationary distribution, used to reset when Scabbers is caught.
        # Scabbers always re-spawns at (0,0) and runs 1000 steps before the next turn starts.
        self.T_stationary = np.linalg.matrix_power(self.T, 1000)  # expensive but only done once

        # Initialize suspicion to the stationary distribution (Scabbers has already been running)
        self.suspicion = self._spawn()

    def _spawn(self):
        # Simulate Scabbers starting at cell (0,0) and taking 1000 random steps.
        # Returns the resulting probability distribution over all cells.
        v = np.zeros(_SZ)   # start with all probability mass at cell 0
        v[0] = 1.0           # cell (0,0) = index 0
        return v @ self.T_stationary  # multiply through the stationary matrix

    def _norm(self):
        # Renormalize suspicion so it sums to 1 after we've zeroed out some cells.
        # If everything got zeroed (shouldn't happen), fall back to the spawn prior.
        s = self.suspicion.sum()                                     # total probability mass remaining
        self.suspicion = self.suspicion / s if s > 0 else self._spawn()  # divide or reset

    def scamper(self):
        # Predict step: Scabbers moves one step according to the transition matrix.
        # Called once per elapsed turn (both ours and opponent's) to advance the model.
        self.suspicion = self.suspicion @ self.T  # matrix multiply shifts all probability mass

    def mischiefsManaged(self):
        # Scabbers was caught — wipe the map and start fresh from the spawn distribution.
        # Called whenever a search lands on Scabbers (either us or opponent).
        self.suspicion = self._spawn()  # reset to post-1000-step stationary distribution

    def notHere(self, loc):
        # A cell was searched and Scabbers wasn't there — zero it out entirely.
        # Renormalize so the remaining cells still sum to 1.
        self.suspicion[_idx(loc)] = 0.0  # hard zero — we know Scabbers isn't here
        self._norm()                      # redistribute the probability mass

    def hearsay(self, hogwarts, clues):
        # Update step: reweight the map using this turn's sensor readings.
        # clues = (noise_type, estimated_distance) from the game engine.
        # For each cell, compute P(clues | Scabbers in that cell) and multiply into suspicion.
        noise, footsteps = clues          # unpack the two sensor signals
        wx, wy = hogwarts.player_worker.get_location()  # our wizard's current position

        # Build a likelihood vector: one entry per cell, each = P(noise)*P(distance)
        lk = np.array([
            # P(noise | floor_type_at_cell) × P(footsteps | actual_distance_to_cell)
            _RUSTLE.get(hogwarts.get_cell((x, y)), _RUSTLE[Cell.SPACE]).get(noise, 0.33)
            # fallback to SPACE likelihoods for unknown cell types; 0.33 if noise not in table
            * _STEPS.get(
                footsteps - (abs(wx - x) + abs(wy - y)),  # reported_dist minus actual_dist = offset
                0.001   # offset outside {-1,0,1,2} is extremely unlikely but not impossible
            )
            for y in range(BOARD_SIZE) for x in range(BOARD_SIZE)  # iterate every cell row by row
        ])

        self.suspicion *= lk   # Bayesian update: multiply prior by likelihood
        self._norm()            # renormalize so it's still a valid probability distribution

    def mostWanted(self):
        # Return the cell with the highest suspicion and its probability.
        # This is where we should cast Revelio (search for Scabbers).
        i = int(np.argmax(self.suspicion))          # flat index of the most suspicious cell
        return _loc(i), float(self.suspicion[i])    # convert back to (x,y) and return with prob

    def getSuspicion(self, loc):
        # Return the suspicion level for one specific cell — used by Divination.py
        # to pull the heuristic score toward high-probability rat locations.
        return float(self.suspicion[_idx(loc)])  # index into flat array and cast to Python float
